package com.mimi.FoodDelivery.repositories;

import com.mimi.FoodDelivery.entities.Salad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SaladRepository extends JpaRepository<Salad,Long> {
}
