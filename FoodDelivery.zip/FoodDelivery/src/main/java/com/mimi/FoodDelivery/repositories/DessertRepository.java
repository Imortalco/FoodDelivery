package com.mimi.FoodDelivery.repositories;

import com.mimi.FoodDelivery.entities.Dessert;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DessertRepository extends JpaRepository<Dessert,Long> {

}
