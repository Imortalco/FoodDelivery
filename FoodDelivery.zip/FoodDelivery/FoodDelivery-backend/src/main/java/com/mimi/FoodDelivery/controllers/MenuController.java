package com.mimi.FoodDelivery.controllers;


import com.mimi.FoodDelivery.entities.*;
import com.mimi.FoodDelivery.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;


@RestController
@RequestMapping("/menu")
public class MenuController {

    private final BurgerRepository burgerRepository;
    private CityRepository cityRepository;
    private DealsRepository dealsRepository;
    private final DessertRepository dessertRepository;
    private final DrinkRepository drinkRepository;
    private final PizzaRepository pizzaRepository;
    private final SaladRepository saladRepository;
    private final SauceRepository sauceRepository;
    private DistrictRepository districtRepository;
    private final OrderRepository orderRepository;

    MenuController(PizzaRepository pizzaRepository,
                   DessertRepository dessertRepository,
                   BurgerRepository burgerRepository,
                   DrinkRepository drinkRepository,
                   SaladRepository saladRepository,
                   SauceRepository sauceRepository,
                   OrderRepository orderRepository) {
        this.burgerRepository= burgerRepository;
        this.pizzaRepository = pizzaRepository;
        this.dessertRepository = dessertRepository;
        this.drinkRepository = drinkRepository;
        this.saladRepository = saladRepository;
        this.sauceRepository = sauceRepository;
        this.orderRepository = orderRepository;
    }

    @GetMapping("/text")
    public ResponseEntity<?> Text() {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        String currentDate=formatter.format(date);
        Map<String,String> response = new HashMap<>();
        response.put("date:",currentDate);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all")
     public List<Object> getAll() {
        List<Object> foodList = new ArrayList<>();
        foodList.addAll(pizzaRepository.findAll());
        foodList.addAll(burgerRepository.findAll());
        foodList.addAll(dessertRepository.findAll());
        foodList.addAll(drinkRepository.findAll());
        foodList.addAll(saladRepository.findAll());
        foodList.addAll(sauceRepository.findAll());
        return foodList;
    }

    @GetMapping("/burger")
    public ResponseEntity<?> getBurgerByName(@RequestParam(required = false) String name){
        if (name==null || name.isBlank()) return ResponseEntity.ok().body("Не сте задали име");
        Optional<Burger> result = burgerRepository.findByName(name.toLowerCase());
        return  result.isPresent()? ResponseEntity.ok(result) : ResponseEntity.ok("Не е открит запис");
    }

    @GetMapping("/dessert")
    public ResponseEntity<?> getDessertByName(@RequestParam(required = false) String name){
        if (name==null || name.isBlank()) return ResponseEntity.ok().body("Не сте задали име");
        Optional<Dessert> result = dessertRepository.findByName(name.toLowerCase());
        return  result.isPresent()? ResponseEntity.ok(result) : ResponseEntity.ok("Не е открит запис");
    }

    @GetMapping("/drink")
    public ResponseEntity<?> getDrinkByName(@RequestParam(required = false) String name){
        if (name==null || name.isBlank()) return ResponseEntity.ok().body("Не сте задали име");
        Optional<Drink> result = drinkRepository.findByName(name.toLowerCase());
        return  result.isPresent()? ResponseEntity.ok(result) : ResponseEntity.ok("Не е открит запис");
    }

    @GetMapping("/pizza")
    public ResponseEntity<?> getPizzaByName(@RequestParam(required = false) String name){
        if (name==null || name.isBlank()) return ResponseEntity.ok().body("Не сте задали име");
        Optional<Pizza> result = pizzaRepository.findByName(name.toLowerCase());
        return  result.isPresent()? ResponseEntity.ok(result) : ResponseEntity.ok("Не е открит запис");
    }

    @GetMapping("/salad")
    public ResponseEntity<?> getSaladByName(@RequestParam(required = false) String name){
        if (name==null || name.isBlank()) return ResponseEntity.ok().body("Не сте задали име");
        Optional<Salad> result = saladRepository.findByName(name.toLowerCase());
        return  result.isPresent()? ResponseEntity.ok(result) : ResponseEntity.ok("Не е открит запис");
    }

    @GetMapping("/sauce")
    public ResponseEntity<?> getSauceByName(@RequestParam(required = false) String name){
        if (name==null || name.isBlank()) return ResponseEntity.ok().body("Не сте задали име");
        Optional<Sauce> result = sauceRepository.findByName(name.toLowerCase());
        return  result.isPresent()? ResponseEntity.ok(result) : ResponseEntity.ok("Не е открит запис");
    }

    @GetMapping("/search/id")
    public Optional<Dessert> getDessertById(@RequestParam(required = false) Long id){
        return dessertRepository.findById(id);
    }

    @GetMapping("/search/burger/page")
    public  ResponseEntity<?> paginateBurger(@RequestParam(value ="currentPage", defaultValue = "1") int currentPage,
                                            @RequestParam(value="perPage", defaultValue = "5") int perPage,
                                            @RequestParam(required = false) String name) {
        Pageable pageable = PageRequest.of(currentPage-1,perPage);
        Page<Burger> burgers=burgerRepository.findPageBurger(pageable,name.toLowerCase());

        Map<String, Object> response = new HashMap<>();
        response.put("burgers",burgers.getContent());
        response.put("currentPage", burgers.getNumber()+1);
        response.put("totalItems",burgers.getTotalElements());
        response.put("totalPages",burgers.getTotalPages());

        return new ResponseEntity<>(response,HttpStatus.OK);
    }

   /* @PostMapping("/order/save")
    public ResponseEntity<?> saveOrder(@RequestParam(required = false) Long id,
                                       @RequestParam(required = false) String customerName,
                                       @RequestParam(required = false) String orderList) {
        //SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        String currentDate=formatter.format(date);
        Order currentOrder = new Order(id,false,orderList,customerName,currentDate);
        currentOrder = orderRepository.save(currentOrder);
        Map<String,Object> response = new HashMap<>();
        response.put("messаge","Успешно записан");
        return new ResponseEntity<>(response,HttpStatus.OK);
        }
        */


}
