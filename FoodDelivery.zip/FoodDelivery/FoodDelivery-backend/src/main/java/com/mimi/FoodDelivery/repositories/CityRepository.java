package com.mimi.FoodDelivery.repositories;

import com.mimi.FoodDelivery.entities.City;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CityRepository extends JpaRepository<City,Long> {

}
