package com.mimi.FoodDelivery.repositories;

import com.mimi.FoodDelivery.entities.Burger;
import com.mimi.FoodDelivery.entities.Drink;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface DrinkRepository extends JpaRepository<Drink,Long> {

    @Query("SELECT dr FROM Drink dr WHERE lower(dr.drinkName) = :name ")
    Optional<Drink> findByName(String name);
}
